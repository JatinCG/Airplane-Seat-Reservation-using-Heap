class Flights:
    def __init__(self, maxsize=5):
        self._maxsize = maxsize
        self._available = 0
        self._array = [None] * self._maxsize
        self.flight_det = {}                                                                       

    def __len__(self):
        return self._available

    def __getitem__(self, index):
        if not 0 <= index < self._available:
            raise IndexError('Index out of bounds\nflight not available')
        return self._array[index]

    def __setitem__(self, index, value):
        if not 0 <= index < self._available:
            raise IndexError('Index out of bounds\nflight not available')
        self._array[index] = value

    def append(self, value, flight_size, eco_seats, pre_eco_seats, bus_seats):
        if flight_size != eco_seats + pre_eco_seats + bus_seats:
             raise ValueError('Total seat count mismatch.')
        if value in self.flight_det:
            raise ValueError(f"Flight '{value}' already exists.")

        if self._available == self._maxsize:
            self._resize(2 * self._maxsize)

        self._array[self._available] = value
        self._available += 1

    # ✅ Create and store flight seat configuration
        seat_obj = arr_flight_seats(value, flight_size, eco_seats, pre_eco_seats, bus_seats)

        self.flight_det[value] = seat_obj


    def insert(self, index, value, flight_size, eco_seats, pre_eco_seats, bus_seats):
        if not 0 <= index <= self._available:
            raise IndexError('Index out of bounds')
        if self._available == self._maxsize:
            self._resize(2 * self._maxsize)
        for i in range(self._available, index, -1):
            self._array[i] = self._array[i-1]
        self._array[index] = value
        self._available += 1
        self.flight_det[value] = arr_flight_seats(value, flight_size, eco_seats, pre_eco_seats, bus_seats)

    def remove(self, index):
        if self._available == 0:
            raise IndexError('Index Out Of Bounds')
        if not 0 <= index < self._available:
            raise IndexError('Index out of bounds')
        for i in range(index, self._available - 1):
            self._array[i] = self._array[i+1]
        self._available -= 1
        self._array[self._available] = None
        if 0 < self._available < self._maxsize // 4:
            self._resize(self._maxsize // 2)

    def __str__(self):
        return '[' + ', '.join(str(self._array[i]) for i in range(self._available)) + ']'

    def _resize(self, new_maxsize):
        new_array = [None] * new_maxsize
        for i in range(self._available):
            new_array[i] = self._array[i]
        self._array = new_array
        self._maxsize = new_maxsize

    def clear(self):
        self._array = [None] * self._maxsize
        self._available = 0

    def search(self, value):
        for i in range(self._available):
            if self._array[i] == value:
                return print("index is:", i)
        return "Flight not found"
    def get(self, airline):
        return self.flight_det.get(airline)  # or loop through if it's a list


def mysetarr(obj, attr_name, value):
    obj.__dict__[attr_name] = value

def mygetarr(obj, attr_name, default=None):
    return obj.__dict__.get(attr_name, default)

def my_hasattr(obj, attr_name):
    try:
        mygetarr(obj, attr_name)
        return True
    except AttributeError:
        return False



def my_enumerate(iterable, start=0):
    index = start
    for item in iterable:
        yield index, item
        index += 1

def my_len(iterable):
    count = 0
    for _ in iterable:
        count += 1
    return count

class arr_flight_seats:
    def __init__(self,flight_value, total_seats, eco_seats, pre_eco_seats, bus_seats):
        self.flight_value = flight_value
        self.total_seats = total_seats

        # ✅ Cleaner seat list
        self.seats = [None] * total_seats

        self.economy = eco_seats
        self.premium_economy = pre_eco_seats
        self.business = bus_seats

        # ✅ Seat ranges
        self.business_range = (0, bus_seats - 1)
        self.premium_economy_range = (bus_seats, bus_seats + pre_eco_seats - 1)
        self.economy_range = (bus_seats + pre_eco_seats, total_seats - 1)

    def assign_seat(self, passenger_name, seat_type):
        seat_type = seat_type.strip().lower()

        if seat_type == "business":
            start, end = self.business_range
        elif seat_type == "premium economy":
            start, end = self.premium_economy_range
        elif seat_type == "economy":
            start, end = self.economy_range
        else:
            raise ValueError(f"Invalid seat type: {seat_type}")

        for i in range(start, end + 1):
            if self.seats[i] is None:
                self.seats[i] = passenger_name
                print(f"✅ Seat assigned to {passenger_name} on {self.flight_value} ({seat_type}) at position {i+1}")
                return True

        print(f"🚫 No available {seat_type} seats on flight {self.flight_value}.")
        return False



class Passenger_det_Heap:
    def __init__(self, max_size, flight_value, flights):
        self.heap = []
        self.max_size = max_size
        self.flights = flights  # ✅ Use the one passed from app.py
        self.assigned_seats = {}  # airline -> class -> set(seat_numbers)
        mysetarr(self, f"dic_{flight_value}", {})

    def insert(self, airline, priority, passenger_name, seat_type, passenger_id):
        if len(self.heap) >= self.max_size:
            raise OverflowError("Heap is at maximum size")
    
        # Store all details in the heap (priority, airline, name, class, ID)
        heap_entry = (-priority, airline, passenger_name, seat_type, passenger_id)  # Negative for max-heap
        self.heap.append(heap_entry)
        self._heapify_up(len(self.heap) - 1)

        if not hasattr(self, f"dic_{airline}"):
             mysetarr(self, f"dic_{airline}", {})
        self.__dict__[f"dic_{airline}"][passenger_name] = seat_type
    
        # Initialize seat tracking
        if airline not in self.assigned_seats:
            self.assigned_seats[airline] = {}
        if seat_type not in self.assigned_seats[airline]:
            self.assigned_seats[airline][seat_type] = set()

        # DEBUG OUTPUT - CRUCIAL FOR TRACKING
        print(f"\n🔹 [DEBUG] Added to heap:")
        print(f"   Airline: {airline}")
        print(f"   Passenger: {passenger_name} (ID: {passenger_id})")
        print(f"   Class: {seat_type}")
        print(f"   Priority: {priority}")
        print(f"   Current Heap Size: {len(self.heap)}")
        print(f"   Full Heap Contents:")
        for i, entry in my_enumerate(self.heap):
            print(f"     {i}: {entry}")

    def remove_passenger(self, passenger_name):
        for index, (_, airline, name, seat_type, passenger_id) in my_enumerate(self.heap):
            if name == passenger_name:
                self.heap[index], self.heap[-1] = self.heap[-1], self.heap[index]
                removed = self.pop()
                self._heapify_down(index)
                if index < len(self.heap):  # Only heapify up if the index is valid
                    self._heapify_up(index)
                return removed
        return None

    def remove_highest_priority(self):
        if not self.heap:
            return None, None, False
        self.heap[0], self.heap[-1] = self.heap[-1], self.heap[0]
        removed = self.pop()

        # Unpacking the values correctly
        priority = -removed[0]  # Negative because we stored it as -priority for max-heap
        passenger_name = removed[2]
       

        self._heapify_down(0)

        # Seat assignment
        for key in self.__dict__:
            if key.startswith("dic_"):
                flight_name = key.split("dic_")[1]
                seat_type_assigned = self.__dict__[key].get(passenger_name)
                if seat_type_assigned:
                    flight_obj = self.flights.flight_det[flight_name]
                    success = flight_obj.assign_seat(passenger_name, seat_type_assigned)
                    return priority, passenger_name, success

        return priority, passenger_name, False

    def _heapify_up(self, index):
        while index > 0:
            parent = (index - 1) // 2  # Calculate the parent index
            if parent < len(self.heap):  # Check if parent index is valid
                if self.heap[index][0] < self.heap[parent][0]:
                    self.heap[index], self.heap[parent] = self.heap[parent], self.heap[index]
                    index = parent
                else:
                    break
            else:
                break

    def _heapify_down(self, index):
        size = my_len(self.heap)
        while index < size:
            left, right = 2 * index + 1, 2 * index + 2
            smallest = index
            if left < size and self.heap[left][0] < self.heap[smallest][0]:
                smallest = left
            if right < size and self.heap[right][0] < self.heap[smallest][0]:
                smallest = right
            if smallest != index:
                self.heap[index], self.heap[smallest] = self.heap[smallest], self.heap[index]
                index = smallest
            else:
                break

    # def append(self, name):
    #     new_heap = self.heap + [name]
    #     self.heap = new_heap

    def pop(self):
        if not self.heap:
            return None
        removed = self.heap[-1]
        self.heap = self.heap[:-1]
        return removed

    





flights = Flights()
flights.append("INDIGO", 10, 4, 3, 3)
print(flights)  # Should show ['INDIGO']
try:
    flights.append("AIRASIA", 10, 4, 3, 3)
except ValueError as e:
    print("Test passed:", e)
flights.append("AKASA_AIR", 9, 5, 2, 2)
print(flights.flight_det["AKASA_AIR"].economy_range)  # Should be (4, 8)
I6E693 = flights.get("INDIGO")
I6E693.assign_seat("Akhil", "business")
I6E693.assign_seat("Bhaskhar", "premium economy")
I6E693.assign_seat("Charan", "economy")
I6E693.assign_seat("David", "business")
I6E693.assign_seat("Jatin", "business")  # Should print seat assigned
I6E693.assign_seat("Freya", "business")  # Should print "🚫 No available..."
heap = Passenger_det_Heap(max_size=10, flight_value="INDIGO", flights=flights)
heap.insert("INDIGO", priority=5, passenger_name="Zendaya", seat_type="economy", passenger_id="P001")
heap.insert("INDIGO", priority=10, passenger_name="LivinGston", seat_type="economy", passenger_id="P002")
heap.insert("INDIGO", priority=1, passenger_name="Einstein", seat_type="business", passenger_id="P003")

priority, passenger_name, success = heap.remove_highest_priority()
print(f"Removed {passenger_name} with priority {priority}, assigned: {success}")
removed = heap.remove_passenger("Einstein")
print("Removed:", removed)
flights.insert(1, "QR404", flight_size=8, eco_seats=4, pre_eco_seats=2, bus_seats=2)
print(flights)
flights.remove(0)
print(flights)  # Should not contain INDIGO anymore
flights.search("AKASA_AIR")  # Should print index
flights.search("NONEXISTENT")  # Should say not found
print("Test mygetarr:", mygetarr(I6E693, "flight_value"))
print("Test mysetarr (before):", I6E693.total_seats)
mysetarr(I6E693, "total_seats", 20)
print("Test mysetarr (after):", I6E693.total_seats)
print("Has attr:", my_hasattr(I6E693, "business_range"))
print(I6E693.business_range, I6E693.premium_economy_range, I6E693.economy_range)
try:
    I6E693.assign_seat("Xavier", "first class")
except ValueError as e:
    print("Caught error:", e)
for i in range(11):
    try:
        heap.insert("AKASA_AIR", i, f"Passenger{i}", "economy", f"ID{i}")
    except OverflowError as e:
        print("Heap full:", e)





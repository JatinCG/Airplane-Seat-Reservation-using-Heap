# connectioN.py

import mysql.connector
from contextlib import contextmanager

def get_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='3753',
        database='flight_booking_2'
    )

@contextmanager
def db_cursor(dictionary=False):
    conn = get_connection()
    cursor = conn.cursor(dictionary=dictionary)
    try:
        yield cursor
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

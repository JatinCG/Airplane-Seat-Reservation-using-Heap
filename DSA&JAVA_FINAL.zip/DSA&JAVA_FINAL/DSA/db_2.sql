CREATE DATABASE flight_booking_2;

USE flight_booking_2;

CREATE TABLE flights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    airline VARCHAR(100),
    origin VARCHAR(100),
    destination VARCHAR(100),
    departure_time TIME,
    arrival_time TIME,
    duration VARCHAR(50),
    price DECIMAL(10,2)
);

CREATE TABLE passengers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    flight_id INT,
    class VARCHAR(50),
    FOREIGN KEY (flight_id) REFERENCES flights(id)
);

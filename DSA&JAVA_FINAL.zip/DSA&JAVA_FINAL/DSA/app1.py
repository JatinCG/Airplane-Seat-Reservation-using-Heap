from flask import Flask, render_template, request, redirect, url_for
from connectioN import db_cursor
from backend import Flights, Passenger_det_Heap
import uuid
import random

app = Flask(__name__)

# === INIT ===
flights_logic = Flights()
heap = Passenger_det_Heap(138, "default", flights_logic)



def normalize_class(c):
    c = c.strip().lower()
    if 'premium' in c:
        return 'premium economy'
    elif 'business' in c:
        return 'business'
    return 'economy'


def generate_seat_label(airline, seat_class):
    print(f"\n=== DEBUG: Starting seat assignment for {airline} ({seat_class}) ===")
    print(f"Current heap assigned seats: {heap.assigned_seats}")
    
    flight = flights_logic.get(airline)
    if not flight:
        print(f"DEBUG: Flight {airline} not found in flights_logic!")
        return "Standby"
    
    print(f"DEBUG: Flight found - Business: {flight.business}, Premium: {flight.premium_economy}, Economy: {flight.economy}")

    seat_config = {
        "Business": {
            "rows": range(1, flight.business // 2 + 1),
            "letters": ["A", "B"],
            "total": flight.business
        },
        "Premium Economy": {
            "rows": range(1, flight.premium_economy // 3 + 1),
            "letters": ["A", "B", "C"],
            "total": flight.premium_economy
        },
        "Economy": {
            "rows": range(1, flight.economy // 4 + 1),
            "letters": ["A", "B", "C", "D"],
            "total": flight.economy
        }
    }

    config = seat_config.get(seat_class)
    if not config:
        print(f"DEBUG: Invalid seat class {seat_class}")
        return "Standby"

    if airline not in heap.assigned_seats:
        heap.assigned_seats[airline] = {}
    if seat_class not in heap.assigned_seats[airline]:
        heap.assigned_seats[airline][seat_class] = set()

    print(f"DEBUG: Current assigned seats for {airline}/{seat_class}: {heap.assigned_seats[airline][seat_class]}")
    print(f"DEBUG: Trying to assign from {config['rows']} rows with letters {config['letters']}")

    for row in config["rows"]:
        for letter in config["letters"]:
            seat = f"{row}{letter}"
            if seat not in heap.assigned_seats[airline][seat_class]:
                heap.assigned_seats[airline][seat_class].add(seat)
                print(f"DEBUG: Assigned seat {seat}")
                return seat

    print("DEBUG: No available seats - standby")
    return "Standby"





# === ROUTES ===
@app.route('/')
def homepage():
    return render_template('Homepage.html')


@app.route('/checkin')
def checkin_page():
    return render_template('web-checkin.html')


@app.route('/admin')
def admin_page():
    return render_template('Admin.html')


@app.route('/search', methods=['POST'])
def search_flights():
    origin = request.form.get('origin')
    destination = request.form.get('destination')

    with db_cursor(dictionary=True) as cursor:
        cursor.execute("""
            SELECT * FROM flights 
            WHERE origin = %s AND destination = %s
        """, (origin, destination))
        flights = cursor.fetchall()

    return render_template('available.html', flights=flights)


@app.route('/add-flight', methods=['POST'])
def add_flight():
    data = request.form

    airline = data['airline']
    flight_size = int(data['flight_size'])
    eco = int(data['eco_seats'])
    pre = int(data['pre_eco_seats'])
    bus = int(data['bus_seats'])

    # Save to DB
    with db_cursor() as cursor:
        cursor.execute("""
            INSERT INTO flights (
                airline, origin, destination,
                departure_time, arrival_time, duration, price,
                flight_size, eco_seats, pre_eco_seats, bus_seats
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            airline, data['origin'], data['destination'],
            data['departure'], data['arrival'], data['duration'],
            data['price'], flight_size, eco, pre, bus
        ))

    # Update in-memory logic
    flights_logic.append(airline, flight_size, eco, pre, bus)

    return redirect(url_for('homepage'))


@app.route('/book', methods=['POST'])
def book_flight():
    data = request.form

    name = data['name'].strip().lower()
    email = data['email'].strip().lower()
    passenger_id = str(uuid.uuid4())[:8]
    seat_type = normalize_class(data['seat_type']).title()
    airline = data['airline']
    priority = 1  # Default priority

    print(f"\n=== DEBUG: Booking passenger {name} ===")
    print(f"Passenger ID: {passenger_id}")
    print(f"Airline: {airline}, Class: {seat_type}")

    # Insert into heap (CRITICAL FIX)
    heap.insert(airline, priority, name, seat_type, passenger_id)
    print(f"Heap after booking: {heap.heap}")  # Verify insertion

    # Insert into DB
    with db_cursor() as cursor:
        cursor.execute("""
            INSERT INTO passengers (
                passenger_id, name, email, class, airline, 
                origin, destination, time, duration, price, seat_number
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            passenger_id, name, email, seat_type, airline,
            data['origin'], data['destination'], data['time'],
            data['duration'], data['price'], "Not Assigned"
        ))

    return render_template("booking_success.html", 
                         passenger_id=passenger_id, 
                         name=name)


@app.route('/process-checkin', methods=['POST'])
def process_checkin():
    global heap
    print("\n=== DEBUG: Starting check-in process ===")
    
    passenger_id = request.form['passenger_id'].strip()
    print(f"DEBUG: Checking in passenger ID: {passenger_id}")

    with db_cursor(dictionary=True) as cursor:
        try:
            # Verify the passenger exists
            cursor.execute("""
                SELECT passenger_id, name, email, class, airline, 
                       origin, destination, seat_number 
                FROM passengers 
                WHERE passenger_id = %s
            """, (passenger_id,))
            passenger = cursor.fetchone()

            if not passenger:
                print("DEBUG: Passenger not found in database")
                return render_template('checkin_status.html', 
                                       message="Passenger not found.")

            print(f"DEBUG: Passenger record: {passenger}")
            
            if not all(k in passenger for k in ['passenger_id', 'airline', 'class']):
                missing = [k for k in ['passenger_id', 'airline', 'class'] if k not in passenger]
                print(f"DEBUG: Missing fields in passenger record: {missing}")
                return render_template('checkin_status.html',
                                       message="Database record incomplete.")

            airline = passenger['airline']
            seat_class = passenger['class']
            
            print(f"DEBUG: Processing check-in for {passenger_id} on {airline} ({seat_class})")

            # Search heap for passenger
            passenger_found = None
            print(f"DEBUG: Current heap ({len(heap.heap)} passengers):")
            for i, item in enumerate(heap.heap):
                print(f"  {i}: {item}")
                if len(item) >= 5 and item[4] == passenger_id:
                    passenger_found = (i, item[1], item[2], item[3], item[4])
                    break

            if not passenger_found:
                print("DEBUG: Passenger not found in heap")
                return render_template('checkin_status.html',
                                       passenger=passenger,
                                       message="Passenger not found in check-in queue.")

            # Remove from heap
            index, airline, pname, pclass, pid = passenger_found
            heap.heap[index], heap.heap[-1] = heap.heap[-1], heap.heap[index]
            heap.heap.pop()
            heap._heapify_down(0)
            print(f"DEBUG: Heap after removal ({len(heap.heap)} passengers remaining)")

            # Assign seat
            seat = generate_seat_label(airline, seat_class)
            print(f"DEBUG: Assigned seat: {seat}")

            # Update database
            cursor.execute(
                "UPDATE passengers SET seat_number = %s WHERE passenger_id = %s",
                (seat, passenger_id)
            )

            passenger['seat_number'] = seat
            msg = f"Seat Assigned: {seat}" if seat != "Standby" else "You are on the standby list."
            print(f"DEBUG: Check-in complete. Result: {msg}")
            
            return render_template('checkin_status.html', 
                                   passenger=passenger, 
                                   message=msg)

        except Exception as e:
            print(f"ERROR: Check-in failed: {str(e)}")
            return render_template('checkin_status.html',
                                   message=f"Check-in error: {str(e)}")



@app.route('/reset-flights')
def reset_flights():
    with db_cursor() as cursor:
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        cursor.execute("TRUNCATE TABLE passengers")
        cursor.execute("TRUNCATE TABLE flights")
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")

    # Reset backend logic too
    global flights_logic, heap
    flights_logic = Flights()
    heap = Passenger_det_Heap(138, "default", flights_logic) 

    return redirect(url_for('homepage'))


if __name__ == '__main__':
    app.run(debug=True)

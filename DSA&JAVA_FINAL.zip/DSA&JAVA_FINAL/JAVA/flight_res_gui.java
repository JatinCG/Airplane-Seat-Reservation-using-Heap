package java_project_package;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class flight_res_gui {

	private JFrame frame;
	private JTextField textField;
	private JTextArea textArea;
	private JTextArea textArea_1;

	// Reservation logic fields
	private static final int ECONOMY_SEATS = 10;
	private static final int BUSINESS_SEATS = 5;
	private static final int OVERBOOK_LIMIT = 2;

	private static String[] economySeats = new String[ECONOMY_SEATS];
	private static String[] businessSeats = new String[BUSINESS_SEATS];
	private static String[] standbyList = new String[OVERBOOK_LIMIT];
	private static int standbyCount = 0;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				flight_res_gui window = new flight_res_gui();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public flight_res_gui() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1043, 544);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(240, 240, 240));

		Font labelFont = new Font("SansSerif", Font.BOLD, 14);
		Font buttonFont = new Font("SansSerif", Font.BOLD, 12);
		Font textAreaFont = new Font("Monospaced", Font.PLAIN, 12);
		Color primaryColor = new Color(46, 134, 222);
		Color textColor = new Color(51, 51, 51);

		JLabel lblNewLabel = new JLabel("Passenger Name");
		lblNewLabel.setFont(labelFont);
		lblNewLabel.setForeground(textColor);
		lblNewLabel.setBounds(41, 23, 150, 32);
		frame.getContentPane().add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(205, 26, 161, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Select Class");
		lblNewLabel_1.setFont(labelFont);
		lblNewLabel_1.setForeground(textColor);
		lblNewLabel_1.setBounds(41, 71, 150, 14);
		frame.getContentPane().add(lblNewLabel_1);

		JComboBox<String> comboBox = new JComboBox<>(new String[] { "Economy", "Business" });
		comboBox.setBounds(201, 67, 90, 22);
		frame.getContentPane().add(comboBox);

		JButton btnNewButton = new JButton("Reserve");
		styleButton(btnNewButton, primaryColor, buttonFont);
		btnNewButton.setBounds(324, 67, 89, 23);
		frame.getContentPane().add(btnNewButton);

		textArea = new JTextArea();
		styleTextArea(textArea, textAreaFont);
		textArea.setBounds(475, 71, 453, 37);
		frame.getContentPane().add(textArea);

		JButton btnNewButton_1 = new JButton("View Seats");
		styleButton(btnNewButton_1, primaryColor, buttonFont);
		btnNewButton_1.setBounds(41, 111, 120, 23);
		frame.getContentPane().add(btnNewButton_1);

		textArea_1 = new JTextArea();
		styleTextArea(textArea_1, textAreaFont);
		textArea_1.setBounds(186, 119, 310, 189);
		frame.getContentPane().add(textArea_1);

		JButton btnNewButton_2 = new JButton("Exit");
		styleButton(btnNewButton_2, primaryColor, buttonFont);
		btnNewButton_2.setBounds(427, 473, 89, 23);
		frame.getContentPane().add(btnNewButton_2);

		JTextArea textArea_2 = new JTextArea();
		styleTextArea(textArea_2, textAreaFont);
		textArea_2.setBounds(612, 119, 335, 189);
		frame.getContentPane().add(textArea_2);

		JTextArea textArea_3 = new JTextArea();
		styleTextArea(textArea_3, textAreaFont);
		textArea_3.setBounds(180, 333, 748, 127);
		frame.getContentPane().add(textArea_3);

		btnNewButton.addActionListener(e -> {
			String name = textField.getText().trim();
			String selectedClass = (String) comboBox.getSelectedItem();

			if (name.isEmpty()) {
				textArea.setText("Please enter a name.");
				return;
			}

			String message;
			if (selectedClass.equals("Economy")) {
				if (reserveEconomySeat(name)) {
					message = "Economy seat reserved for " + name;
				} else {
					addToStandbyList(name);
					message = "Economy is full. " + name + " added to standby list.";
				}
			} else {
				if (reserveBusinessSeat(name)) {
					message = "Business seat reserved for " + name;
				} else {
					addToStandbyList(name);
					message = "Business is full. " + name + " added to standby list.";
				}
			}

			textArea.setText(message);
			textField.setText("");
		});

		btnNewButton_1.addActionListener(e -> {
			StringBuilder eco = new StringBuilder();
			StringBuilder bus = new StringBuilder();
			StringBuilder standby = new StringBuilder();

			eco.append("Economy Class Seats:\n");
			for (int i = 0; i < ECONOMY_SEATS; i++) {
				eco.append("Seat " + (i + 1) + ": " + (economySeats[i] != null ? economySeats[i] : "Available") + "\n");
			}

			bus.append("Business Class Seats:\n");
			for (int i = 0; i < BUSINESS_SEATS; i++) {
				bus.append("Seat " + (i + 1) + ": " + (businessSeats[i] != null ? businessSeats[i] : "Available") + "\n");
			}

			standby.append("Standby List:\n");
			if (standbyCount == 0) {
				standby.append("No passengers on standby.");
			} else {
				for (int i = 0; i < standbyCount; i++) {
					standby.append((i + 1) + ". " + standbyList[i] + "\n");
				}
			}

			textArea_1.setText(eco.toString());
			textArea_2.setText(bus.toString());
			textArea_3.setText(standby.toString());
		});

		btnNewButton_2.addActionListener(e -> System.exit(0));
	}

	private void styleButton(JButton button, Color background, Font font) {
		button.setBackground(background);
		button.setForeground(Color.WHITE);
		button.setFont(font);
		button.setFocusPainted(false);
	}

	private void styleTextArea(JTextArea area, Font font) {
		area.setFont(font);
		area.setBackground(Color.WHITE);
		area.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
	}

	private boolean reserveEconomySeat(String name) {
		for (int i = 0; i < ECONOMY_SEATS; i++) {
			if (economySeats[i] == null) {
				economySeats[i] = name;
				return true;
			}
		}
		return false;
	}

	private boolean reserveBusinessSeat(String name) {
		for (int i = 0; i < BUSINESS_SEATS; i++) {
			if (businessSeats[i] == null) {
				businessSeats[i] = name;
				return true;
			}
		}
		return false;
	}

	private void addToStandbyList(String name) {
		if (standbyCount < standbyList.length) {
			standbyList[standbyCount] = name;
			standbyCount++;
		} else {
			textArea.setText("Standby list is full. Cannot add more passengers.");
		}
	}
}